﻿export const GAME_INFO = {
  id: 'pulso-runner',
  name: 'Pulso Runner',
  version: '1.0.0',
  orientation: 'landscape' as const,
  minPlayers: 1,
  maxPlayers: 1,
  supportsPoints: true,
  resultSchemaVersion: 1
};

export const PHYSICS_CONFIG = {
  gravity: 2000,      // Equivalente a 0.7 en tu escala HTML
  jumpPower: -900,    // Equivalente a -14 en tu escala HTML
  baseSpeed: 300,
  speedIncrement: 15,
  minGapFactor: 3.5,
  hitboxPadding: 18
};