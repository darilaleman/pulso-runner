﻿import Phaser from 'phaser';
import { GamePlatform, GameResult } from '../../cubaplay/GamePlatform';
import { GAME_INFO, PHYSICS_CONFIG } from '../config/GameConfig';

export class GameScene extends Phaser.Scene {
  private platform!: GamePlatform;
  private player!: Phaser.Physics.Arcade.Sprite;
  private obstacles!: Phaser.Physics.Arcade.Group;
  private scoreText!: Phaser.GameObjects.Text;
  
  private score: number = 0;
  private speed: number = PHYSICS_CONFIG.baseSpeed;
  private startTime: number = 0;
  private isGameOver: boolean = false;

  constructor(platform: GamePlatform) {
    super('GameScene');
    this.platform = platform;
  }

  preload() {
    this.load.image('player', '/assets/pulso-running.png');
  }

  create() {
    this.startTime = performance.now();
    this.score = 0;
    this.speed = PHYSICS_CONFIG.baseSpeed;
    this.isGameOver = false;

    const w = this.scale.width;
    const h = this.scale.height;
    
    // --- ESCALA DINÁMICA (Idéntica a tu HTML) ---
    const scaleRatio = Math.min(h / 400, 1.5);
    const playerSize = 60 * scaleRatio;
    const groundY = h - 50;

    // Suelo
    const ground = this.add.rectangle(w / 2, groundY + 25, w, 50, 0x333333);
    this.physics.add.existing(ground, true);
    this.add.rectangle(w / 2, groundY, w, 4, 0xff3333);

    // Jugador
    let textureKey = 'playerPlaceholder';
    if (this.textures.exists('player')) {
      textureKey = 'player';
    } else {
      const g = this.make.graphics({ x: 0, y: 0, add: false });
      g.fillStyle(0xff3333);
      g.fillRect(0, 0, 60, 60);
      g.generateTexture('playerPlaceholder', 60, 60);
    }

    this.player = this.physics.add.sprite(w * 0.1, groundY, textureKey);
    
    // CORRECCIÓN CLAVE: Anclar el sprite desde abajo (pies)
    this.player.setOrigin(0.5, 1); 
    
    // Escalar visualmente el sprite
    if (textureKey === 'player') {
      this.player.setScale(playerSize / 60);
    }

    this.player.setCollideWorldBounds(true);
    
    // Hitbox escalada dinámicamente
    const padding = PHYSICS_CONFIG.hitboxPadding * scaleRatio;
    this.player.body!.setSize(playerSize - padding * 2, playerSize - padding * 1.5);
    this.player.body!.setOffset(padding, padding);

    this.physics.add.collider(this.player, ground);

    // Obstáculos
    this.obstacles = this.physics.add.group({ allowGravity: false, immovable: true });
    this.physics.add.overlap(this.player, this.obstacles, () => this.gameOver());

    // UI
    this.scoreText = this.add.text(20, 20, 'Puntos: 0', {
      fontSize: `${32 * scaleRatio}px`, 
      fontFamily: 'system-ui', 
      color: '#ff3333',
      fontStyle: '800'
    });

    // Controles
    this.input.keyboard?.on('keydown-SPACE', () => this.jump());
    this.input.on('pointerdown', () => this.jump());
  }

  update(time: number, delta: number) {
    if (this.isGameOver) return;

    const w = this.scale.width;
    const h = this.scale.height;
    const scaleRatio = Math.min(h / 400, 1.5);
    const groundY = h - 50;

    // Generación por distancia
    const minGap = this.player.width * PHYSICS_CONFIG.minGapFactor;
    const lastObs = this.obstacles.getChildren().slice(-1)[0] as any;
    
    if (!lastObs || (w - lastObs.x) >= minGap) {
      const randomExtraGap = Math.random() * (this.player.width * 2);
      if (!lastObs || (w - lastObs.x) >= minGap + randomExtraGap) {
        this.spawnObstacle(w, groundY, scaleRatio);
      }
    }

    this.obstacles.children.each((obs: any) => {
      obs.x -= this.speed * (delta / 1000);
      if (!obs.getData('passed') && obs.x + obs.width < this.player.x) {
        obs.setData('passed', true);
        this.score += 10;
        this.scoreText.setText('Puntos: ' + this.score);
        if (this.score % 50 === 0) this.speed += PHYSICS_CONFIG.speedIncrement;
      }
      if (obs.x + obs.width < -50) obs.destroy();
    });
  }

  private jump() {
    if (this.isGameOver) return;
    if (this.player.body!.touching.down || this.player.body!.blocked.down) {
      this.player.setVelocityY(PHYSICS_CONFIG.jumpPower);
    }
  }

  private spawnObstacle(screenWidth: number, groundY: number, scaleRatio: number) {
    const maxJumpH = (Math.pow(PHYSICS_CONFIG.jumpPower, 2) / (2 * PHYSICS_CONFIG.gravity)) * 0.8;
    const minHeight = 30 * scaleRatio;
    const maxHeight = Math.min(maxJumpH, 90 * scaleRatio);
    const height = Phaser.Math.Between(minHeight, maxHeight);
    const width = 35 * scaleRatio;

    const obs = this.obstacles.create(screenWidth, groundY - height / 2, null) as Phaser.Physics.Arcade.Sprite;
    
    const g = this.make.graphics({ x: 0, y: 0, add: false });
    g.fillStyle(0x000000);
    g.fillRect(0, 0, width, height);
    g.lineStyle(2 * scaleRatio, 0xff3333);
    g.strokeRect(0, 0, width, height);
    g.generateTexture('obs_' + Math.round(height), width, height);
    
    obs.setTexture('obs_' + Math.round(height));
    obs.body!.setSize(width, height);
    obs.setData('passed', false);
  }

  private gameOver() {
    if (this.isGameOver) return;
    this.isGameOver = true;
    this.physics.pause();
    this.player.setTint(0xff0000);

    const duration = performance.now() - this.startTime;
    const result: GameResult = {
      gameId: GAME_INFO.id,
      gameVersion: GAME_INFO.version,
      score: this.score,
      durationMs: Math.round(duration),
      statistics: { obstaclesPassed: Math.floor(this.score / 10) }
    };

    this.platform.submitResult(result);
  }
}