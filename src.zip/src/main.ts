﻿import Phaser from 'phaser';
import { WebTestPlatform } from './cubaplay/WebTestPlatform';
import { GameScene } from './game/scenes/GameScene';

async function init() {
  const platform = new WebTestPlatform();
  await platform.initialize();
  await platform.startGame();

  const config: Phaser.Types.Core.GameConfig = {
    type: Phaser.AUTO,
    width: window.innerWidth,
    height: window.innerHeight,
    backgroundColor: '#1a1a1a',
    parent: 'game-container',
    scale: { mode: Phaser.Scale.RESIZE, autoCenter: Phaser.Scale.CENTER_BOTH },
    physics: {
      default: 'arcade',
      arcade: { gravity: { y: 700 }, debug: false }
    },
    scene: [new GameScene(platform)]
  };

  new Phaser.Game(config);
}

init();
